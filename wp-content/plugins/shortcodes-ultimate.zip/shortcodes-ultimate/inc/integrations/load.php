<?php

/**
 * Class for managing integrations with other plugins
 */
class Su_Integrations {

}